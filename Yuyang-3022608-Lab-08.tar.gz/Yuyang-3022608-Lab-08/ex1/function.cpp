/*
 * File Name: function.cpp
 * Author: Yuyang Fan
 * Assignmenr: EECS 168 LAB 8
 * Discription: bunch of functions
 * Date: Oct 29 2020
 *
 */
 
 
#include <iostream>
#include <math.h>

using namespace std;


int lastdigit(int num)
{
	int divide_num = 10;
	int ans;
	ans = num%divide_num;
	
	return(ans);
}

int removelastdigit(int num)
{
	int ans;
	ans = num/10;
	
	return(ans);
}

int adddigit (int num,int addnum)
{
	double divide_num=10;
	int ans;
	int deter_value=0;
	do
	{
		
		if (addnum/divide_num < 1)
		{
			ans= num*divide_num+addnum;
			deter_value = 1;
		}
		else
		{
			divide_num=divide_num*10;
		}
		
	}while (deter_value==0);
	
	return(ans);
}

int reverse (int num)
{
	int deter_value=0;
	int divide_num=10;
	int ans=0;
	int exspace = num;
	do
	{
		ans = adddigit(ans, lastdigit(num));
		num = removelastdigit(num);
		if ( exspace/divide_num <1)
		{
			deter_value = 1;
		}
		else 
		{
			divide_num=divide_num*10;
		}
		
	}while (deter_value == 0);
	
	return(ans);
}

bool ispalindrome (int num)
{
	bool palindrome = 0;
	if (num == reverse(num))
	{
		palindrome = 1;
	}
	
	return (palindrome);
}

int coutdigits (int num)
{
	int times=0;
	
	while (num != 0)
	{
		num = removelastdigit(num);
		times++;
	}
	
	return (times);
}

int sumdigits (int num)
{
	int sum=0;
	while (num != 0)
	{
		sum = sum + lastdigit(num);
		num = removelastdigit(num);
	}
	
	return(sum);
}

bool isprime (int num)
{
	bool prime = 1;
	
	if (num == 1)
	{ prime = 0;}
	else if (num == 2)
	{ prime = 1;}

	else 
	{
		for (int i=2; i<num; i++)
		{
			if (num%i == 0)
			{
				prime =0;
				i=num+1;
			}
		}
	}
	
	return (prime);
}
			
void printmenu()
{
	cout << "1) Count digits" <<endl;
	cout << "2) Sum digits\n";
	cout << "3) Is palindrome\n";
	cout << "4) Reverse\n";
	cout << "5) Is Prime\n";
	cout << "6) Exit\n";
	cout << "Choice: ";

return;
}

void run()
{
	int choice;
	int num;
	int final_choice = 0;
	do
	{
		
		printmenu();
		cin >> choice;
		if (choice ==1 || choice ==2 || choice ==3 || choice ==4 || choice ==5)
		{
			cout <<"What is the integer?: ";
			cin >> num;
		}
		if (choice == 1)
		{
			cout <<"It has "<<coutdigits(num)<<" number(s).\n";
		}
		else if (choice ==2)
		{
			cout <<"The sum is " << sumdigits(num)<<".\n";
		}
		else if (choice == 3)
		{
			if (ispalindrome(num) == 1)
			{cout<<"Is palindrome!\n";}
			else
			{cout<<"Not palindrome!\n";}
		}
		else if (choice ==4)
		{
			cout <<"The reserve integer is " << reverse(num) << ".\n";
		}
		else if (choice == 5)
		{
			if (isprime(num)==1)
			{cout << "Is Prime!\n";}
			else
			{cout << "Not Prime!\n";}
		}
		else if (choice == 6)
		{
			final_choice = 1;
		}
		else 
		{
			cout <<"Invalid, choice again!\n";
		}
		
	}while (final_choice == 0);
	
	return;
}
	




int main()
{
	run();
	return(0);
}
	


