#include <iostream>
int main()
{
	std::cout << "My name is Yuyang Fan.\nI am EECS major.\n"
	<< "My hobbies are:\n\tVideo games\n\tMusic\n\tCooking\n"
	<< "Goodbye\n";

}
