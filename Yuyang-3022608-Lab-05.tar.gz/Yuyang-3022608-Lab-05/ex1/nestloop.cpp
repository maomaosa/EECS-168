/*
 *
 * File Name: nestloop.cpp
 * Author: Yuyang Fan
 * Assignment: EECS 168 LAB 5
 * Discription: patterns of nested loops
 * Date: Sep 30
 *
 */


#include <iostream>
using namespace std;

int main()
{
	int choice;
	char fianl_choice;




	do
	{
		cout << "1) Checkerboard\n2) Rook Path\n3) Running Total\n4) Upper Left Triangle\n5) Upper Right Triangle\n\nInput a choice: ";
		cin >> choice;
		cout << endl;
		
		if (choice==1)
		{

			int size1;
			
			do 
			{
				cout << "Input a size: ";
				cin >> size1;
				if (size1<=3)
				{ cout << "Invalid size, try a bigger one.\n";}
			}while (size1 <=3);
			
			int deter_value=1;
			for (int x=1; x<=size1 ;x++)
			{
			
				
				for (int y=1; y<= size1 ; y++)
				{
			
					if (deter_value==1)
					{cout << "O"; deter_value-- ;}
					else
					{cout << "X"; deter_value++ ;}
				
				}
				cout <<endl;
				
				
			}
			cout << "Do you want to quit (y/n)? ";
			cin >> fianl_choice;
		
			
		}
		
		
		else if (choice==2)
		{
			int size2, x_value, y_value;
			
			do 
			{
				cout << "Input a size: ";
				cin >> size2;
				if (size2<=3)
				{ cout << "Invalid size, try a bigger one.\n";}
			}while (size2 <=3);
			
			cout << "Input the x_value of the position: ";
			cin >> x_value;
			cout << "Input the y_value of the position: ";
			cin >> y_value;
			
			for (int x=1; x<=size2; x++)
			{
				
				for (int y=1; y<=size2; y++)
				{
					
					if (x==x_value+1 && y!= y_value+1)
					{cout << "-";}
					else if (x!=x_value+1 && y==y_value+1)
					{cout << "|";}
					else if (x==x_value+1 && y==y_value+1)
					{cout << "R";}
					else
					{cout << "*";}
				}
				cout << endl;
				
			}
			cout << "Do you want to quit (y/n)? ";
			cin >> fianl_choice;
		}
		
		
		
		
		else if (choice==3)
		{
			
			int size3;
			
			do 
			{
				cout << "Input a size: ";
				cin >> size3;
				if (size3<=3)
				{ cout << "Invalid size, try a bigger one.\n";}
			}while (size3 <=3);
			
			int value=1;
			
			for (int x=1; x<=size3; x+=1)
			{
				
				
				for (int y=1; y<=size3; y+=1)
				{
					if (y==size3)
					{cout << value << endl; value=value+1;}
					else 
					{cout << value <<","; value=value+1;}
				}
				
			}
			cout << "Do you want to quit (y/n)? ";
			cin >> fianl_choice;
		}
		
		
		else if (choice==4)
		{
			
			int size4;
			
			do 
			{
				cout << "Input a size: ";
				cin >> size4;
				if (size4<=3)
				{ cout << "Invalid size, try a bigger one.\n";}
			}while (size4 <=3);
			
			int y_size;
			y_size=size4;
			
			for (int x=1; x<=size4; x+=1)
			{
				
				for (int y=1; y<=y_size; y++)
				{cout << "*"; }
			
			y_size=y_size-1;
			cout << endl;
			}
			cout << "Do you want to quit (y/n)? ";
			cin >> fianl_choice;
		}
		
		
		else if (choice==5)
		{
			
			int size5;
			do 
			{
				cout << "Input a size: ";
				cin >> size5;
				if (size5<=3)
				{ cout << "Invalid size, try a bigger one.\n";}
			}while (size5 <=3);
			
			for (int x=1; x<=size5; x++)
			{
				
				for ( int n=1; n<=x-1;n++)
				{cout<< " ";}
			
				for (int y=1; y<= size5-x+1; y++)
				{cout << "*";}
			
			cout <<endl;
			}
			cout << "Do you want to quit (y/n)? ";
			cin >> fianl_choice;
		}
		
		else
		{
			
			cout << "Invalid choice,choice again!\n";
			fianl_choice='n';
			
		}
				
			




	}while (fianl_choice=='n');
	
	cout << "Goodbye...\n";








return (0);
}
