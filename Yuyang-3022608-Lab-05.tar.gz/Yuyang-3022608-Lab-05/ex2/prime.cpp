/*
 *
 * File Name: prime.cpp
 * Author: Yuyang Fan
 * Assignment: EECS 168 LAB 5
 * Discription: Show the number of prime
 * Date: Sep 30
 *
 */


#include <iostream>
using namespace std;


int main()
{
	char final_choice;

	do
	{
		int number;
		cout << "How many primes do you want to dispaly?: ";
		cin >> number;
		if (number > 0)
		{
			if (number==1)
			{cout << "2\n";}

			
			else
			{
				cout << "2" <<endl;
				
				int times=1;
				int result;
				
				
				for(int x=3; x>0; x++)
				{
						
					for (int y=2; y<x; y++)
					{
						result=x%y;
						if (result !=0)
						{}
						else
						{y=x+1;}
						if (y == x-1)
						{cout << x <<endl; times=times+1;}
					}
					
					if (times == number)
					{x=-1;}
				}
					
				
				
			}
			
			cout << "Type (Q/q) to exit: ";
			cin >>final_choice;
			
		}
		
		else
		{cout<< "Error! Please enter a positive value to see primes.\nType (Q/q) to exit: ";
		cin >> final_choice;}
		
	}while (final_choice !='Q' && final_choice!='q');
	
	return (0);
	
}

