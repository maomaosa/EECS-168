/*
 * File Name: array.cpp
 * Author: Yuyang Fan
 * Assignment: EECS 168 Lab 7
 * Discription: Get input.txt and prodece lots od output context
 * Date: Oct 23
 *
 */

#include<iostream>
#include<fstream>
#include<string>

using namespace std;

int main()
{
	string filename;
	int row, col;
	double** num=nullptr;
	
	ifstream infile;
	do
	{
		cout << "Input the file name (including .txt): ";
		cin >> filename;
		infile.open(filename);
		if(!infile.is_open())
		{
			cout << "Invalid name, check it!\n" ;
		}
	}while (!infile.is_open());
	
	infile >> row >>col;
	
	num = new double*[row];
	for(int i=0;i<row;i++)
	{
		num[i] = new double[col];
	}
	
	for (int i=0;i<row; i++)
	{
		for (int j=0; j<col;j++)
		{
			infile >> num[i][j];
		}
	}
	
	infile.close();

	
	ofstream ofile;
	

	double* sum = nullptr;
	sum = new double [row];
	double total_sum;
	for(int i=0; i<row; i++)
	{
		for(int j=0; j<col; j++)
		{
			sum[i]+=num[i][j];
		}
	}
	for(int i=0;i<row;i++)
	{
		total_sum+=sum[i];
	}
	
	ofile.open("averages.txt");
	ofile <<"Total averages: "<<total_sum/row/col<<endl;
	for(int i=0; i<row; i++)
	{
		ofile <<"Row "<< i+1 <<" average is: " << sum[i]/col<<endl;
	}
	delete[] sum;
	ofile.close();
	
	
	ofile.open("reverse.txt");
	for(int i=0;i<row;i++)
	{
		for(int j=col-1; j>=0;j--)
		{
			ofile << num[i][j]<<" ";
		}
		ofile <<endl;
	}
	ofile.close();
	
	
	ofile.open("flipped.txt");
	for(int i=row-1; i>=0; i--)
	{
		for(int j=0; j<col;j++)
		{
			ofile << num[i][j]<<" ";
		}
		ofile << endl;
	}
	ofile.close();
	
	
	if(row == col)
	{

		ofile.open("diagonal.txt");
		for(int i=0; i<row;i++)
		{
			for(int j=0; j<col;j++)
			{
				ofile << num[j][i]<<" ";
			}
			ofile << endl;
		}
		ofile.close();
		
	}
	else
	{
		ofile.open("transpose.txt");
		for (int i=0; i<col; i++)
		{
			for(int j=0; j<row;j++)
			{
				ofile << num[j][i]<<" ";
			}
			ofile << endl;
		}
		ofile.close();
	}
	
	for(int i=0;i<row;i++)
	{
		delete[] num[i];
	}
	delete[] num;

	cout << "Complete!\n";
	
	
	
	
	
	
	return(0);
}

