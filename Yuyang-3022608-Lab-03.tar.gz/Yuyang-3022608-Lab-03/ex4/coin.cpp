/*
 * File Name: coin.cpp
 * Author: Yuyang Fan
 * Assignment: EECS 168 lab 3
 * Discription: differentiate coins
 * Date: Sep 18
 */

#include <iostream>
using namespace std;

int main()
{
	int coins;
	cout << "How many pennies do you have? ";
	cin >> coins;
	cout << "Quaters: " << coins/25<<endl;
	cout << "Dimes: " << coins%25/10<<endl;
	cout << "Nickels: " << coins%25%10/5<< endl;
	cout << "Pennies: " << coins%25%10%5 <<endl;

	return (0);



}

