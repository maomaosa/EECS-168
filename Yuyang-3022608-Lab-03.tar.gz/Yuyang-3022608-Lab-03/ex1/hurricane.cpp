/*
 * File Name: hurricane.cpp
 * Author: Yuyang Fan
 * Assignment: EECS 168 Lab3
 * Discription:measure the level of hurricane
 * Data: Sep 18
 */

#include <iostream>
using namespace std;
int main()
{
	int hurricane=0;
	cout << "Input a wind speed(m/s): ";
	cin >> hurricane;
	if (hurricane >=70)
	{cout << "A wind speed of "<<hurricane<< "m/s is a Category 5 hurricane.\n";}
	else if (hurricane >=58)
	{cout << "A wind speed of "<<hurricane<< "m/s is a Category 4 hurricane.\n";}
	else if (hurricane >=50)
        {cout << "A wind speed of "<<hurricane<< "m/s is a Category 3 hurricane.\n";}
	else if (hurricane >=43)
        {cout << "A wind speed of "<<hurricane<< "m/s is a Category 2 hurricane.\n";}
	 else if (hurricane >=33)
        {cout << "A wind speed of "<<hurricane<< "m/s is a Category 1 hurricane.\n";}
	else if (hurricane >=18)
        {cout << "A wind speed of "<<hurricane<< "m/s is a tropical stom\n.";}
	else if (hurricane >=0)
        {cout << "A wind speed of "<<hurricane<< "m/s is a tropical depression.\n";}
	else
	{cout << "Nagative wind? Sorry, that's invalid.\n";}

return (0);


}
