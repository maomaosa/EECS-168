/*
 *File Name: recipe.cpp
 *Author: Yuyang Fan
 *Assinment: EECS 168 lab 3
 *Dirscription: Restaurant Recipe
 *Date: Sep 18
 */
 
#include <iostream>
using namespace std;

int main()
{
	cout.precision(2);
	cout << std::fixed;
	
	
	int age=0;
	char tacochoice; int taconum;
	char sushichoice; int sushinum;
	char desertschoice; int desertsnum;
	cout<<"============================\n"<<"WELCOME TO THE RESTAURANT\n" <<"============================\n";
	cout<<"Do you want Tacos? (y/n): ";
	cin >>tacochoice;

	if (tacochoice == 'Y' || tacochoice == 'y')
	{ cout<<"How many?: ";
	  cin >> taconum;
	  if (taconum<=0)
	  {
		  taconum=0;
	  }
	}
	
	else // (tacochoice == 'N' || tacochoice == 'n')
	{ taconum=0; 
	}
	
	
	cout<< "\nDo you wan Sushi? (y/n): ";
	cin >>sushichoice;
	if (sushichoice == 'Y' || sushichoice == 'y')
	{ cout<<"How many?: ";
	  cin >> sushinum;
	  if (sushinum<=0)
	  {
		  sushinum=0;
	  }
	}
	else // (sushichoice == 'N' || sushichoice == 'n')
	{ sushinum=0; 
	}
	
	
	cout<< "\nDo you wan Deserts? (y/n): ";
	cin >>desertschoice;
	if (desertschoice == 'Y' || desertschoice == 'y')
	{ cout<<"How many?: ";
	  cin >> desertsnum;
	  if (desertsnum<=0)
	  {
		  desertsnum=0;
	  }
	}
	else // (desertsnum == 'N' || desertsnum == 'n')
	{ desertsnum=0; 
	}
	
	cout << "How old are you?: ";
	cin >> age;
	if (age <= 12)
	{
		cout << "============================\n"
		<<taconum<< " Tacos @ $3.50 ==> $"<<taconum*3.50
		<<"\n"<< sushinum<<" Sushi @ $7.25 ==> $" <<sushinum*7.25
		<<"\n"<< desertsnum<<" Deserts @ $5.50 ==> $" <<desertsnum*5.50
		<<"\nSubtotal: $"<< taconum*3.50+sushinum*7.25+desertsnum*5.50
		<<"\nTax: $" << (taconum*3.50+sushinum*7.25)*0.5
		<<"\nDiscount: $" << desertsnum*5.50
		<<"\n============================\n"
		<<"Total: $"<< taconum*3.50+sushinum*7.25+(taconum*3.50+sushinum*7.25)*0.5
		<<"\n\nPlease come again!\n";
	}
		
	else if  (age <65)
	{
		cout << "============================\n"
		<<taconum<< " Tacos @ $3.50 ==> $"<<taconum*3.50
		<<"\n"<< sushinum<<" Sushi @ $7.25 ==> $" <<sushinum*7.25
		<<"\n"<< desertsnum<<" Deserts @ $5.50 ==> $" <<desertsnum*5.50
		<<"\nSubtotal: $"<< taconum*3.50+sushinum*7.25+desertsnum*5.50
		<<"\nTax: $" << (taconum*3.50+sushinum*7.25+desertsnum*5.50)*0.5
		<<"\nDiscount: $0.00"
		<<"\n============================\n"
		<<"Total: $"<< taconum*3.50+sushinum*7.25+desertsnum*5.50+(taconum*3.50+sushinum*7.25+desertsnum*5.50)*0.5
		<<"\n\nPlease come again!\n";
	}
	
	else
	{
		cout << "============================\n"
		<<taconum<< " Tacos @ $3.50 ==> $"<<taconum*3.50
		<<"\n"<< sushinum<<" Sushi @ $7.25 ==> $" <<sushinum*7.25
		<<"\n"<< desertsnum<<" Deserts @ $5.50 ==> $" <<desertsnum*5.50
		<<"\nSubtotal: $"<< taconum*3.50+sushinum*7.25+desertsnum*5.50
		<<"\nTax: $" << (taconum*3.50+sushinum*7.25+desertsnum*5.50)*0.5
		<<"\nDiscount: $" << 0.1*(taconum*3.50+sushinum*7.25+desertsnum*5.50+(taconum*3.50+sushinum*7.25+desertsnum*5.50)*0.5)
		<<"\n============================\n"
		<<"Total: $"<< 0.9*(taconum*3.50+sushinum*7.25+desertsnum*5.50+(taconum*3.50+sushinum*7.25+desertsnum*5.50)*0.5)
		<<"\n\nPlease come again!\n";
	}
	
	

	
	
	
	
	
	
	return(0);
	
	
	
	
}	
