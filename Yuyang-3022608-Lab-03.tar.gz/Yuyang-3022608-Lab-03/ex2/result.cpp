/*
 * Fiel Name:result.cpp
 * Author: Yuyang Fan
 * Assignment: EECS 168 lab 3
 * Discription: result of numerator divide by denominator
 * Date: Sep 18
 *
 */

#include <iostream>
using namespace std;

int main()
{
	int numerator=0; int denominator=0;
	cout << "Enter a numerator: ";
	cin >> numerator;
	cout << "Enter a denominator: ";
        cin >> denominator;
	if (denominator != 0)
	{  cout << numerator <<" / "<< denominator <<" = "<< numerator/denominator<<" Remainder "<<numerator%denominator <<endl; }

	else
	{ cout << "Sorry, you may not divide by zero" <<endl; } 
	return(0);

}
