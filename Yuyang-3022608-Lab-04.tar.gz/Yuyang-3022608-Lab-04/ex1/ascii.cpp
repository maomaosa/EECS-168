/*
 *
 * File Name: ascii.cpp
 * Author: Yuyang Fan
 * Assignment: EECS 168 Lab 4
 * Discription: Showing the ASCII
 * Date: Sep 23
 *
 */

#include <iostream>
using namespace std;
int main()
{
	int num, choice, x;
	do
	{
	cout << "1) Select a specific number\n2) Display visible ACSCII values (33 to 126)\n3) Exit\nChoice: ";
	cin >> choice;
	if (choice == 1)
	{
		cout << "Enter value: ";
		cin >> num;
		char symbol=static_cast<char>(num);
		cout <<num << " = "<< symbol<<endl;
	
	}
	else if (choice == 2)
	{
		for (x=33; x<127; x=x+1)
		{
			char symbol=static_cast<char>(x);
			cout << x << " = " << symbol <<endl;
			
		}
	
	}
	else if (choice == 3)
	{
	
	}
	else
	{
		cout << "This choice is invaild! Select again!\n";
	}

	}while (choice!=3);
	return (0);
}
