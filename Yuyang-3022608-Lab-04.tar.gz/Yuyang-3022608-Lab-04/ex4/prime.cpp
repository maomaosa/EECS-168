/*
 *
 * File Name: prime.cpp
 * Author: Yuyang Fan
 * Assignment: EECS 168 LAB4
 * Discription: Prime detector
 * Date: Sep 23
 *
 */
#include <iostream>
using namespace std;

int main()
{
	

	int num, times,result;
	cout << "Enter a number: ";
	cin >> num;
	if (num==2)
	{cout << "Prime\n";}
	else if (num>2)
	{
		for (times=2; times<num; times=times+1)
		{
			result=num%times;
			if (result !=0)
			{}
			else
			{
				cout << "Not Prime\n";
				times=num+1;
			}
			if (times == num-1)
        		{cout << "Prime\n";}

		}


	}

	else
	{cout << "Invalid\n";}


	return (0);

}
