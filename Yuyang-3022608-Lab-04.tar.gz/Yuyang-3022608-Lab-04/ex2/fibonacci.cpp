/*
 *File Name: fibonacci.cpp
 *Author: Yuyang Fan
 *Assignment: EECS 168 LAB 4
 *Discription: Showing the fibonacci number
 *Date: Sep 23
 *
 */

#include <iostream>
using namespace std;

int main()
{
	
	long long int times=2, fibo_num, fibo1=0, fibo2=1, fibo3;// to show more numbers√ 
	cout<< "How many Fibonacci numbers do you want printed?: ";
	cin >> fibo_num;
	if (fibo_num == 1)
	{ cout << "0\n"; }
	else if (fibo_num == 2)
	{ cout << "0, 1\n"; }
	else
	{
		cout << "0, 1";
		while (times<fibo_num)
			{
				fibo3=fibo1+fibo2;
				fibo1=fibo2;
				fibo2=fibo3;
				times=times+1;
				cout <<", "<< fibo3;

			}
		cout <<endl;
	}
	return (0);
}

