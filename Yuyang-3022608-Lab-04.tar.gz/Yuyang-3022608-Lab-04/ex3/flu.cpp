/*
 * File Name: flu.cpp
 * Author: Yuyang Fan
 * Assignment: EECS 168 LAB 4
 * Discription: show the Flu by days
 * Date: Sep 23
 */

#include <iostream>
using namespace std;

int main()
{
	int flu_day, d1=1, d2=5, d3=17, d4, times=4;

	cout << "OUTBREAK!\nWhat day do you want a sick count for?: ";
	cin >> flu_day;
	if (flu_day==1)
	{cout << "Total people with flu : 1\n";}
	else if (flu_day==2)
	{cout << "Total people with flu : 5\n";}
	else if (flu_day==3)
	{cout << "Total people with flu : 17\n";}
	else if (flu_day>=4)
	{
		while (times<flu_day)
		{
			d4=d1+d2+d3;
			d1=d2;
			d2=d3;
			d3=d4;
			times=times+1;
		}
		cout << "Total people with flu: " << d1+d2+d3<<endl;
	}
	else
	{cout << "Invalid day\n";}

	return (0);
			



}

