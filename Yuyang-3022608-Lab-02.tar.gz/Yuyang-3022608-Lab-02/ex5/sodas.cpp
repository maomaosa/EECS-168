/*
 *
 * File Name: sadas.cpp
 * Author: Yuyang Fan
 * Assignment: EECS 168 lab 2
 * Discription: The methods of how to pack sodas
 * Data: Sep 12
 *
 */

#include <iostream>
int main()
{
	using namespace std;
	int sodas;
	cout << "How many sodas do you have?: ";
	cin >> sodas;
	cout << "Fridges Cubes: " << (sodas/24) << endl;
	int six_packs= sodas%24;
	cout << "Six_packs: " << (six_packs/6) <<endl;
	cout << "Singles: " << (six_packs%6) << endl ;

	return (0);

}
