/*
 *
 * File Name: quadratic.cpp
 * Author: Yuyang Fan
 * Assignment: EECS 168 Lab2
 * Discription: calulationg the roots for quadatic equation
 * Date: Sep 12
 *
 */

#include <iostream> 
#include <math.h>
int main()
{
	using namespace std;
	double a=0.0; double b=0.0; double c=0.0;
	double d=0.0;	// for b^2-4ac
	cout << "Input a: ";
	cin >> a;
	cout << "Input b: ";
	cin >> b;
	cout << "Input c: ";
	cin >> c;
	d= b*b-4*a*c;
	cout << "root 1: " << (-b+sqrt(d))/(2*a) <<"\n";
	cout << "root 2: " << (-b-sqrt(d))/(2*a) <<endl;
	
	return(0);
}
