/*
 *
 * File Name: temperature.cpp
 * Author: Yuyang Fan
 * Asiignment: EECS-168 Lab2
 * Discription: changing temperature from Fahrenheit to Celsius
 * Date: Sep 12
 *
 */


#include <iostream>
int main()
{
	using namespace std;
	double tem_f=0.0;
	cout << "What is the temperature in Fahrenheit?: ";
	cin >> tem_f;
	cout << "Oh, the temperature in Celsius is " << (tem_f-32)*(5.0/9) << "°C!\n";
	
	return (0);

}
