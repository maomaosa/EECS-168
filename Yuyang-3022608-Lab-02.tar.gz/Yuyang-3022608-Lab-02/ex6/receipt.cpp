/*
 *
 * File Name: receipt.cpp
 * Author: Yuyang Fan
 * Assignment: EECS 168 Lab 2
 * Driscription: Taco receipt
 * Date: Sep 12
 *
 */
 
#include <iostream>
int main()
{
	using namespace std;
	char choice; int quantity; 
	cout << "Welcome to the taco stand!!!\n\nPlace order:\n============\n(c/C) Chicken Taco $3.50\n(s/S) Salad $5.0\n(w/W) Water $1.0\nChoice:";
	cin >> choice;
	int choice_value=static_cast<int>(choice);
	
		if((choice_value) == 67 || (choice_value == 99)) //(c/C)
		{
			using namespace std;
			cout << "Toppings:\n============\n(t/T) Tomatoes $0.75\n(c/C) Cheese $1.5\n(h/H) Hot Sauce $0.3\n(n/N) None $0.0\nChoice:";
			char topping_choice;
			cin >> topping_choice;
			int topping_choice_value = static_cast<int>(topping_choice);
			if((topping_choice_value == 84) || (topping_choice_value == 116)) //(t/T)
			{
				using namespace std;
				cout << "Quantity:\n============\nHow many?:";
				cin >> quantity ;
				cout << "Receipt:\n============\nSub total\n\t" << quantity << " Chicken Taco @ $3.5: $" << (quantity*3.5) <<"\n\t"
				<< quantity << " Tomatoes @ $0.75: $" << (quantity*0.75) << "\n"
				<< "Tax\n" << "\t8% of $"<< (quantity*3.5+quantity*0.75) << ": $" << (0.08*(quantity*3.5+quantity*0.75)) << "\n"
				<< "Total\n\t$" << ((quantity*3.5+quantity*0.75)+(0.08*(quantity*3.5+quantity*0.75))) << "\n"
				<< "Thank you!" << endl;

			}
			else if((topping_choice_value == 67) || (topping_choice_value == 99))
			{
				using namespace std;
				cout << "Quantity:\n============\nHow many?:";
				cin >> quantity ;
				cout << "Receipt:\n============\nSub total\n\t" << quantity << " Chicken Taco @ $3.5: $" << (quantity*3.5) <<"\n\t"
				<< quantity << " Cheese @ $1.5: $" << (quantity*1.5) << "\n"
				<< "Tax\n" << "\t8% of $"<< (quantity*3.5+quantity*1.5) << ": $" << (0.08*(quantity*3.5+quantity*1.5)) << "\n"
				<< "Total\n\t$" << ((quantity*3.5+quantity*1.5)+(0.08*(quantity*3.5+quantity*1.5))) << "\n"
				<< "Thank you!" << endl;
			}
			else if((topping_choice_value == 72) || (topping_choice_value == 104))
			{
				using namespace std;
				cout << "Quantity:\n============\nHow many?:";
				cin >> quantity ;
				cout << "Receipt:\n============\nSub total\n\t" << quantity << " Chicken Taco @ $3.5: $" << (quantity*3.5) <<"\n\t"
				<< quantity << " Hot Sauce @ $0.3: $" << (quantity*0.3) << "\n"
				<< "Tax\n" << "\t8% of $"<< (quantity*3.5+quantity*0.3) << ": $" << (0.08*(quantity*3.5+quantity*0.3)) << "\n"
				<< "Total\n\t$" << ((quantity*3.5+quantity*0.3)+(0.08*(quantity*3.5+quantity*0.3))) << "\n"
				<< "Thank you!" << endl;
			}
			else if((choice_value == 78) || (choice_value == 110))
			{
				using namespace std;
				cout << "Quantity:\n============\nHow many?:";
				cin >> quantity ;
				cout << "Receipt:\n============\nSub total\n\t" << quantity << " Chicken Taco @ $3.5: $" << (quantity*3.5) << "\n"
				<< "Tax\n" << "\t8% of $"<< (quantity*3.5) << ": $" << (0.08*(quantity*3.5)) << "\n"
				<< "Total\n\t$" << ((quantity*3.5)+(0.08*(quantity*3.5))) << "\n"
				<< "Thank you!" << endl;
			}
			else
			{
			using namespace std;
			cout << "Your choice is not executable!\n";
			}
		}
		else if((choice_value == 83) || (choice_value == 115))
		{
				using namespace std;
				cout << "Quantity:\n============\nHow many?:";
				cin >> quantity ;
				cout << "Receipt:\n============\nSub total\n\t" << quantity << " Salad @ $5.0: $" << (quantity*5.0) << "\n"
				<< "Tax\n" << "\t8% of $"<< (quantity*5.0) << ": $" << (0.08*(quantity*5.0)) << "\n"
				<< "Total\n\t$" << ((quantity*5.0)+(0.08*(quantity*5.0))) << "\n"
				<< "Thank you!" << endl;
		}
		else if((choice_value == 87) || (choice_value == 119))
		{
				using namespace std;
				cout << "Quantity:\n============\nHow many?:";
				cin >> quantity ;
				cout << "Receipt:\n============\nSub total\n\t" << quantity << " Water @ $1.0: $" << (quantity*1.0) << "\n"
				<< "Tax\n" << "\t8% of $"<< (quantity*1.0) << ": $" << (0.08*(quantity*1.0)) << "\n"
				<< "Total\n\t$" << ((quantity*1.0)+(0.08*(quantity*1.0))) << "\n"
				<< "Thank you!" << endl;
		}
		else
		{
			using namespace std;
			cout << "Your choice is not executable!\n";
		}
		
	
	return (0);
}
