/*
 *
 * File Name: exchange.cpp
 * Author: Yuyang Fan
 * Assignment: EECS 168 Lab 2
 * Discription: Casting ints and chars
 * Date: Sep 12
 *
 */

#include <iostream>

int main()
{
	char symbol;
	using namespace std;
	cout << "Input a character: ";
	cin >> symbol;
	int value = static_cast <int> (symbol);
	cout << "The ASCII value for '" << symbol << "' is: " << value
	       	<< "\nGoodbye!\n";
	return (0);

}
