/*
 *
 *File Name: hypotenuse.cpp
 *Author: Yuyang Fan
 *Assignment: EECS-168 Lab 2
 *Description: Calculating the hypotenuse
 *Date: Sep 12
 *
 */

#include <iostream>
#include <math.h>
int main()
{
	using namespace std;
	double a=0.0; double b=0.0; 
	cout << "This will use formula a^2+b^2=c^2 to solve for the hypotenuse of a triangle\n";
	cout << "Input a value for a: ";
	cin >> a;
	cout << "Input a value for b: ";
	cin >> b;
	cout << "The hypotenuse is: "<< sqrt (a*a+b*b)<<"\n";
	return (0);

}



