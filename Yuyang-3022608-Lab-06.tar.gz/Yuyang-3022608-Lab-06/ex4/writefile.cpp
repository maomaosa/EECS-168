/*
 * File Name: writefile.cpp
 * Author: Yuyang FaN
 * Assignment: EECS168 LAB6
 * Discription: rewrite the file from user
 * Date: Oct 15
 *
 */

#include<iostream>
#include<fstream>
#include<string>

using namespace std;

int main()
{
	
	string file_name=" ";
	ifstream infile;
	
	do
	{
		cout << "What is the name of file?(including .txt):";
		cin >> file_name;
		infile.open(file_name);
		if (infile.is_open())
		{}
		else
		{cout<<"File could not be opened, check it.\n";}
	
	}while(!infile.is_open());
	
	int size;
	double* num=nullptr;
	infile >> size;
	num =new double[size];
	for(int i=0;i<size;i++)
	{
		infile>> num[i];
	}
	infile.close();
	
	
	int index=0;
	double extra_space;
	double smallest;
	for(int i=0;i<size;i++)
	{
		smallest=num[0];
		
		for(int j=0;j<size-i;j++)
		{
			
			if (num[j] <= smallest)
			{
				smallest=num[j];
				index=j;
			}
			
			if(j==size-i-1)
			{
				
				if (num[index]==num[j])
				{}
				else
				{
					extra_space=num[j];
					num[j]=num[index];
					num[index]=extra_space;
		
				}
			}
		}
	}
	
	
	std::ofstream outfile;
	outfile.open ("normalized.txt");
	outfile << "Original array: [";
	for(int i=0; i<size-1;i++)
	{
		outfile << num[i]<<", ";
	}
	outfile << num[size-1] <<"]\n";
	
	outfile << "Normalized array: [";
	for (int i=0; i<size-1; i++)
	{
		if (i==0)
		{outfile << "1, ";}
		else
		{outfile << (num[i]-num[size-1])/(num[0]-num[size-1])<<", ";}
	}
	outfile << "0]";
	outfile.close();
	
	
	
	
	outfile.open ("reserved.txt");
	outfile << "Original array: [";
	for(int i=0; i<size-1;i++)
	{
		outfile << num[i]<<", ";
	}
	outfile << num[size-1] <<"]\n";
	
	outfile<< "Reversed arrary: [";
	for (int i=size-1; i>0; i--)
	{
		outfile<< num[i] <<", ";
	}
	outfile << num[0]<<"]";
	outfile.close();
			
	
	
	cout << "Colplete!!!\n";
	


	
	
	delete[] num;
	return(0);
	
}
	