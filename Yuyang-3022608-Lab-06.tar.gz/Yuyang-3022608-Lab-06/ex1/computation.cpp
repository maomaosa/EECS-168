/*
 * File Name: Computation.cpp
 * Author: Yuyang Fan
 * Assignment: EECS 168 LAB 6
 * Discription: Output Numeric Computation
 * Date: Oct 15
 *
 */

#include <iostream>
using namespace std;

int main()
{
	double numbers[5];
	
	
	
	cout << "Please enter 5 numbers\n";
	cout << "Input a number into your arrary: ";
	cin >> numbers[0];
	cout << "Input a number into your arrary: ";
	cin>> numbers[1];
	cout << "Input a number into your arrary: ";
	cin >>numbers[2];
	cout << "Input a number into your arrary: ";
	cin >> numbers[3];
	cout << "Input a number into your arrary: ";
	cin >> numbers[4];
	
	cout << "Here are all the numbers in your array: \n";
	for (int i=0; i<5 ;i++)
	{
		cout << numbers[i]<<endl;
	}
	
	cout << "The sum of all the values is: ";
	double sum=0.0;
	for (int i=0; i<5 ;i++)
	{
		sum=sum+numbers[i];
	}
	cout << sum <<endl;
	
	cout << "The average of all the values is: " <<sum/5<<endl;
	
	
	double largest=0.0;
	for (int i=0; i<5; i++)
	{
		if (numbers[i] >= largest)
		{
			largest = numbers[i];
		}
	}
	cout << "The largest value is : "<< largest << endl;
	
	
	double smallest=numbers[0];
	for (int i=0; i<5 ;i++)
	{
		if (numbers[i]<=smallest)
		{
			smallest = numbers[i];
		}
	}
	cout << "The smallest value is : " << smallest<< endl;
	
	return(0);
	
}
	
