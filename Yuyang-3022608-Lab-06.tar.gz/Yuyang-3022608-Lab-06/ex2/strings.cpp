/*
 * File Name: strings.cpp
 * Author: Yuyang Fan
 * Assignment: EECS 168 LAB 6
 * Discription: Show the arrarys od strings
 * Date: Oct 15
 *
 */


#include<iostream>
#include<string>

using namespace std;

int main()
{
	string* words = nullptr;
	int size;
	
	
	int deter_value;
	do
	{
		cout << "Input an arrary size for your words arrary: ";
		deter_value=0;
		cin >> size;
		if (size<1)
		{
			cout << "Invalid, Try a bigger one!";
			deter_value++;
		}
	}while(deter_value !=0);
	
	words = new string[size];
	
	cout << "Now please enter "<<size<<" words\n";
	for (int i=0; i<size; i++)
	{
		cout << "Input a word: ";
		cin >> words[i];
	}
	
	unsigned int longest=0;
	string longest_word;
	for (int i=0; i<size; i++)
	{
		if(words[i].length() >= longest)
		{
			longest = words[i].length();
			longest_word=words[i];
		}
	}
	cout << "The longest word is : " << longest_word << endl;
	
	unsigned int shortest=words[0].length();
	string shortest_word;
	for (int i=0; i<size; i++)
	{
		if(words[i].length() <= shortest)
		{
			shortest=words[i].length();
			shortest_word=words[i];
		}
	}
	cout << "The shortest word is : " << shortest_word <<endl;
	
	delete[] words;
	
	
	
	
	
	
	
	
	
	
	return(0);
}