/*
 * File Name: infile.cpp
 * Author: Yuyang Fan
 * Assignment: EECS168 LAB6
 * Discription: Read the number from file.
 * Date: Oct 15
 *
 */

#include<iostream>
#include<fstream>

using namespace std;

int main()
{
	ifstream infile;
	infile.open ("input.txt");
	
	if(infile.is_open())
	{
		int size;
		infile>> size;
		int* numbers = nullptr;
		numbers = new int[size];
		for (int i=0; i<size; i++)
		{
			infile >> numbers[i];
		}
		cout << "The contents of input.txt:\n[";
		for (int i=0; i<size-1; i++)
		{
			cout << numbers[i] << ",";
		}
		cout << numbers[size-1]<<"]\n\n";
		
		
		int search_value;
		char final_choice;
		
		
		do
		{
			cout << "Input a value to search for: ";
			cin >> search_value;
			
			for (int i=0; i<size ;i++)
			{
				if (search_value == numbers[i])
				{
					i=size+1;
					cout <<search_value<<" is in the array.\n";
				}
				if (i==size-1)
				{
					cout <<search_value<<" is not in the array.\n";
				}
			}
			
			cout<< "Do you wish to quit?(y/n): ";
			cin >> final_choice;
		}while(final_choice != 'y');
		
		delete[] numbers;
		infile.close();
	}
	else
	{
		cout <<"File could not be opened!\n";
	}
	
	
	
	
	
	return(0);
}
	