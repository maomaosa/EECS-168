#ifndef CIRCLEDRIVER_H
#define CIRCLEDRIVER_H

#include "circle.h"

class circledriver
{
	public:
	
	circle circle1;
	circle circle2;
	
	void obtaincircles();
	void printcircleinfo();
	void run();
};
	
#endif