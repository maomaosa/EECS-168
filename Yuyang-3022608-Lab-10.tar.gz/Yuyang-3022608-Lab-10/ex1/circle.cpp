#include "circle.h"
#include <math.h>

double circle::diameter()
{
	double ans=0;
	ans = 2*radius;
	return(ans);
}

double circle::area()
{
	double ans=0;
	ans = M_PI*radius*radius;
	return(ans);
}

double circle::circumference()
{
	double ans=0;
	ans = 2*M_PI*radius;
	return(ans);
}

double circle::distancetoorigin()
{
	double ans=0;
	ans = sqrt(xpos*xpos+ypos*ypos);
	return(ans);
}

bool circle::intersect(circle ex)
{
	double distance = sqrt((ypos-ex.ypos)*(ypos-ex.ypos)+(xpos-ex.xpos)*(xpos-ex.xpos));
	if(distance >= (radius+ex.radius) || distance <= abs(radius-ex.radius) )
	{
		return false;
	}
	else
	{
		return true;
	}
}

int circle::intersectcount(circle ex)
{
	int ans;
	double distance = sqrt((ypos-ex.ypos)*(ypos-ex.ypos)+(xpos-ex.xpos)*(xpos-ex.xpos));
	if (distance > (radius+ex.radius) || distance < abs(radius-ex.radius) )
	{
		ans=0;
	}
	else if (distance == (radius+ex.radius) || distance == abs(radius-ex.radius) )
	{
		ans=1;
	}
	else
	{
		ans=2;
	}
	
	return(ans);
}