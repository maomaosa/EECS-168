#ifndef CIRCLE_H
#define CIRCLE_H

class circle
{
	public:
	
	double radius;
	double xpos;
	double ypos;
	
	double diameter();
	double area();
	double circumference();
	double distancetoorigin();
	bool intersect(circle othercircle);
	int intersectcount(circle class_hao_fan_a);
	
};

#endif