/*
 * Filename: main.cpp
 * Author: Yuyang Fan
 * Assignmenr: EECS 168 LAB 10
 * Discription: Class of cricle
 * Date: Nov 12
 *
 */

#include "circledriver.h"

int main()
{
	circledriver mydriver;
	mydriver.run();
	return(0);
}
