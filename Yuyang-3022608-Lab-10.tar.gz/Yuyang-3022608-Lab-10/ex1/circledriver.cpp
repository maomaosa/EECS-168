#include "circledriver.h"
#include "circle.h"
#include <iostream>

using namespace std;

void circledriver::obtaincircles()
{
	cout << "Enter information for circle 1: \n";
	cout << "Radius: ";
	cin >> circle1.radius;
	cout << "X Postion: ";
	cin >> circle1.xpos;
	cout << "Y Postion: ";
	cin >> circle1.ypos;
	
	cout << "Enter information for circle 2: \n";
	cout << "Radius: ";
	cin >> circle2.radius;
	cout << "X Postion: ";
	cin >> circle2.xpos;
	cout << "Y Postion: ";
	cin >> circle2.ypos;

	return;
}

void circledriver::printcircleinfo()
{
	cout << "\nInformation for Cricle 1: \n";
	cout << "location: (" <<circle1.xpos<<","<<circle1.ypos<<")\n";
	cout << "diameter: " <<circle1.diameter()<<endl;
	cout << "area: " << circle1.area()<<endl;
	cout << "circumference: " <<circle1.circumference()<<endl;
	cout << "distance from the origin: "<<circle1.distancetoorigin()<<endl<<endl;
	
	cout << "Information for Cricle 2: \n";
	cout << "location: (" <<circle2.xpos<<","<<circle2.ypos<<")\n";
	cout << "diameter: " <<circle2.diameter()<<endl;
	cout << "area: " << circle2.area()<<endl;
	cout << "circumference: " <<circle2.circumference()<<endl;
	cout << "distance from the origin: "<<circle2.distancetoorigin()<<endl;
	
	if(circle1.intersect(circle2) == 1)
	{
		cout<< "\nThe circles intersect.\n";
	}
	else
	{
		cout << "\nThe circles not intersect.\n";
	}
	cout << "They intersect "<<circle1.intersectcount(circle2)<<" time(s).\n";
	
	
	return;
}

void circledriver::run()
{
	obtaincircles();
	printcircleinfo();
}

