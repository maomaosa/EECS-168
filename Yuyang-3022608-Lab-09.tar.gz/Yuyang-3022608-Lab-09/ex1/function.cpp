/*
 * File Name: function.cpp
 * Author: Yuyang Fan
 * Assignmenr: EECD 168 LAB 9
 * Discription: a bunch of array functions
 * Date: November 5
 *
 */
 
#include <iostream>
#include <string>
#include <fstream>

using namespace std;
ifstream infile;
ofstream outfile;

int* insertnum(int* array,int& size, int num, int position)
{
	size++;
	int* new_array = new int[size];
	for(int i=0; i<size ;i++)
	{
		if (i==position)
		{
			new_array[i]=num;
			
		}
		else if( i > position)
		{
			new_array[i]=array[i-1];
		}
		else
		{
			new_array[i]=array[i];
		}
	}
	
	delete[] array;
	return(new_array);
}

int* removenum (int* array, int& size, int position)
{
	size --;
	int* new_array=new int[size];
	for(int i=0;i<size;i++)
	{
		if(i==position)
		{
			for(;i<size;i++)
			{
				new_array[i]=array[i+1];
			}
			i=size+1;
		}
		else
		{
			new_array[i]=array[i];
		}
	}
	
	delete[] array;
	return(new_array);
}

int countnum(int* array, int size, int num)
{
	int times=0;
	for(int i=0; i<size; i++)
	{
		if (num == array[i])
		{
			times++;
		}
	}
	return(times);
	
}

		
void printarray(int array[], int size)
{
	cout <<"[";
	for(int i=0; i<size; i++)
	{
		if(i==size-1)
		{
			cout << array[i] ;
		}
		else
		{
			cout << array[i]<<", ";
		}
	}
	cout <<"]";
	cout << endl;
	
	return;
}


void save(int array[],int size, string outfilename)
{
	outfile.open(outfilename);
				for (int i=0; i<size; i++)
				{
					outfile << array[i] << endl;
				}
				outfile.close();
		
	return;
}

int main ( int comman_num, char** command )
{
	int choice=0;
	string filename = command[1];
	infile.open(filename);
	
	string size_string = command[2];
	int size = stoi(size_string);
	int* num = new int[size];
	
	if (infile.is_open())
	{
		for (int i=0; i<size ; i++)
		{
			infile >> num[i];
		}
		
		infile.close();
		
		do
		{
			cout << "Make a selection:\n";
			cout <<"1) Insert\n";
			cout <<"2) Remove\n";
			cout <<"3) Count\n";
			cout <<"4) Print\n";
			cout <<"5) Exit\n";
			cout <<"6) Save\n";
			cout <<"Choice: ";
			cin >> choice;
			
			if (choice == 1)
			{
				
				int insert_num, position;
				cout <<"What is the num?: ";
				cin >> insert_num;
				do
				{
					cout << "What is the position?: ";
					cin >> position;
				}while (position<0 || position>size);
				num = insertnum(num,size,insert_num,position);
				
			}
			
			
			if(choice == 2)
			{
	
				int position;
				do
				{
					cout << "Which position do you want to remove?: ";
					cin >> position;
				}while (position<0 || position>size-1);
					
				num=removenum(num, size, position);
				
			}
			
			
			if(choice == 3)
			{
				int search_value;
				cout << "Which vlaue are you searching for?: ";
				cin>> search_value;
				cout << "It has "<<countnum(num,size,search_value)<<" time(s)\n";
			}
				
			
			if (choice == 4)
			{
				printarray(num, size);
			}
			
			
			if (choice == 6)
			{
				string outfilename;
				do
				{
					cout << "What's name of the save file(including .txt): ";
					cin >> outfilename;
				}while (outfilename==filename);
					
				save(num,size,outfilename);
				
				cout <<"Complete!!!\n";
				
			}
			
					
		}while(choice != 5);
				
			
	}
	
	else
	{
		cout << "Invalid file\n";
	}
	
	delete[] num;
	
	
	return (0);
}
